﻿namespace ScorePanel
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ListViewItem listViewItem1 = new ListViewItem("1st");
            ListViewItem listViewItem2 = new ListViewItem("2nd");
            ListViewItem listViewItem3 = new ListViewItem("3rd");
            ListViewItem listViewItem4 = new ListViewItem("4th");
            ListViewItem listViewItem5 = new ListViewItem("5th");
            ListViewItem listViewItem6 = new ListViewItem("6th");
            ListViewItem listViewItem7 = new ListViewItem("7th");
            ListViewItem listViewItem8 = new ListViewItem("8th");
            ListViewItem listViewItem9 = new ListViewItem("9th");
            ListViewItem listViewItem10 = new ListViewItem("10th");
            ListViewItem listViewItem11 = new ListViewItem("1st");
            ListViewItem listViewItem12 = new ListViewItem("2nd");
            ListViewItem listViewItem13 = new ListViewItem("3rd");
            ListViewItem listViewItem14 = new ListViewItem("4th");
            ListViewItem listViewItem15 = new ListViewItem("5th");
            ListViewItem listViewItem16 = new ListViewItem("6th");
            ListViewItem listViewItem17 = new ListViewItem("7th");
            ListViewItem listViewItem18 = new ListViewItem("8th");
            ListViewItem listViewItem19 = new ListViewItem("9th");
            ListViewItem listViewItem20 = new ListViewItem("10th");
            ListViewItem listViewItem21 = new ListViewItem("1st");
            ListViewItem listViewItem22 = new ListViewItem("2nd");
            ListViewItem listViewItem23 = new ListViewItem("3rd");
            ListViewItem listViewItem24 = new ListViewItem("4th");
            ListViewItem listViewItem25 = new ListViewItem("5th");
            ListViewItem listViewItem26 = new ListViewItem("6th");
            ListViewItem listViewItem27 = new ListViewItem("7th");
            ListViewItem listViewItem28 = new ListViewItem("8th");
            ListViewItem listViewItem29 = new ListViewItem("9th");
            ListViewItem listViewItem30 = new ListViewItem("10th");
            ListViewItem listViewItem41 = new ListViewItem("1st");
            ListViewItem listViewItem42 = new ListViewItem("2nd");
            ListViewItem listViewItem43 = new ListViewItem("3rd");
            ListViewItem listViewItem44 = new ListViewItem("4th");
            ListViewItem listViewItem45 = new ListViewItem("5th");
            ListViewItem listViewItem46 = new ListViewItem("6th");
            ListViewItem listViewItem47 = new ListViewItem("7th");
            ListViewItem listViewItem48 = new ListViewItem("8th");
            ListViewItem listViewItem49 = new ListViewItem("9th");
            ListViewItem listViewItem50 = new ListViewItem("10th");
            ListViewItem listViewItem51 = new ListViewItem("1st");
            ListViewItem listViewItem52 = new ListViewItem("2nd");
            ListViewItem listViewItem53 = new ListViewItem("3rd");
            ListViewItem listViewItem54 = new ListViewItem("4th");
            ListViewItem listViewItem55 = new ListViewItem("5th");
            ListViewItem listViewItem56 = new ListViewItem("6th");
            ListViewItem listViewItem57 = new ListViewItem("7th");
            ListViewItem listViewItem58 = new ListViewItem("8th");
            ListViewItem listViewItem59 = new ListViewItem("9th");
            ListViewItem listViewItem60 = new ListViewItem("10th");
            ListViewItem listViewItem31 = new ListViewItem("1st");
            ListViewItem listViewItem32 = new ListViewItem("2nd");
            ListViewItem listViewItem33 = new ListViewItem("3rd");
            ListViewItem listViewItem34 = new ListViewItem("4th");
            ListViewItem listViewItem35 = new ListViewItem("5th");
            ListViewItem listViewItem36 = new ListViewItem("6th");
            ListViewItem listViewItem37 = new ListViewItem("7th");
            ListViewItem listViewItem38 = new ListViewItem("8th");
            ListViewItem listViewItem39 = new ListViewItem("9th");
            ListViewItem listViewItem40 = new ListViewItem("10th");
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            tabControl2 = new TabControl();
            tabPage3 = new TabPage();
            tabPage4 = new TabPage();
            tabPage7 = new TabPage();
            label11 = new Label();
            tabPage2 = new TabPage();
            tabControl3 = new TabControl();
            tabPage5 = new TabPage();
            tabPage6 = new TabPage();
            tabPage8 = new TabPage();
            label7 = new Label();
            label6 = new Label();
            label4 = new Label();
            label9 = new Label();
            label8 = new Label();
            label5 = new Label();
            label3 = new Label();
            label2 = new Label();
            listView1 = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            label10 = new Label();
            label1 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            listView2 = new ListView();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            label23 = new Label();
            label24 = new Label();
            label25 = new Label();
            label26 = new Label();
            label27 = new Label();
            listView3 = new ListView();
            columnHeader5 = new ColumnHeader();
            columnHeader6 = new ColumnHeader();
            label37 = new Label();
            label38 = new Label();
            label39 = new Label();
            label40 = new Label();
            label41 = new Label();
            label42 = new Label();
            label43 = new Label();
            label44 = new Label();
            listView5 = new ListView();
            columnHeader9 = new ColumnHeader();
            columnHeader10 = new ColumnHeader();
            label45 = new Label();
            label46 = new Label();
            label47 = new Label();
            label48 = new Label();
            label49 = new Label();
            label50 = new Label();
            label51 = new Label();
            label52 = new Label();
            label53 = new Label();
            listView6 = new ListView();
            columnHeader11 = new ColumnHeader();
            columnHeader12 = new ColumnHeader();
            label54 = new Label();
            label33 = new Label();
            label29 = new Label();
            label28 = new Label();
            label30 = new Label();
            label31 = new Label();
            label32 = new Label();
            label34 = new Label();
            label35 = new Label();
            listView4 = new ListView();
            columnHeader7 = new ColumnHeader();
            columnHeader8 = new ColumnHeader();
            label36 = new Label();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabControl2.SuspendLayout();
            tabPage3.SuspendLayout();
            tabPage4.SuspendLayout();
            tabPage7.SuspendLayout();
            tabPage2.SuspendLayout();
            tabControl3.SuspendLayout();
            tabPage5.SuspendLayout();
            tabPage6.SuspendLayout();
            tabPage8.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(756, 496);
            tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(tabControl2);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(748, 463);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Singleplayer";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            tabControl2.Controls.Add(tabPage3);
            tabControl2.Controls.Add(tabPage4);
            tabControl2.Controls.Add(tabPage7);
            tabControl2.Dock = DockStyle.Fill;
            tabControl2.Location = new Point(3, 3);
            tabControl2.Name = "tabControl2";
            tabControl2.SelectedIndex = 0;
            tabControl2.Size = new Size(742, 457);
            tabControl2.TabIndex = 0;
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(label7);
            tabPage3.Controls.Add(label6);
            tabPage3.Controls.Add(label4);
            tabPage3.Controls.Add(label9);
            tabPage3.Controls.Add(label8);
            tabPage3.Controls.Add(label5);
            tabPage3.Controls.Add(label3);
            tabPage3.Controls.Add(label2);
            tabPage3.Controls.Add(listView1);
            tabPage3.Controls.Add(label1);
            tabPage3.Location = new Point(4, 29);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(734, 424);
            tabPage3.TabIndex = 0;
            tabPage3.Text = "Countdown";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            tabPage4.Controls.Add(label12);
            tabPage4.Controls.Add(label13);
            tabPage4.Controls.Add(label14);
            tabPage4.Controls.Add(label15);
            tabPage4.Controls.Add(label16);
            tabPage4.Controls.Add(label17);
            tabPage4.Controls.Add(label18);
            tabPage4.Controls.Add(label19);
            tabPage4.Controls.Add(listView2);
            tabPage4.Controls.Add(label10);
            tabPage4.Location = new Point(4, 29);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(734, 424);
            tabPage4.TabIndex = 1;
            tabPage4.Text = "Timer";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage7
            // 
            tabPage7.Controls.Add(label20);
            tabPage7.Controls.Add(label21);
            tabPage7.Controls.Add(label22);
            tabPage7.Controls.Add(label23);
            tabPage7.Controls.Add(label24);
            tabPage7.Controls.Add(label25);
            tabPage7.Controls.Add(label26);
            tabPage7.Controls.Add(label27);
            tabPage7.Controls.Add(listView3);
            tabPage7.Controls.Add(label11);
            tabPage7.Location = new Point(4, 29);
            tabPage7.Name = "tabPage7";
            tabPage7.Padding = new Padding(3);
            tabPage7.Size = new Size(734, 424);
            tabPage7.TabIndex = 2;
            tabPage7.Text = "Count move";
            tabPage7.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(201, 36);
            label11.Name = "label11";
            label11.Size = new Size(94, 20);
            label11.TabIndex = 15;
            label11.Text = "Leaderboard";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(tabControl3);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(748, 463);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "1 vs 1";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            tabControl3.Controls.Add(tabPage5);
            tabControl3.Controls.Add(tabPage6);
            tabControl3.Controls.Add(tabPage8);
            tabControl3.Dock = DockStyle.Fill;
            tabControl3.Location = new Point(3, 3);
            tabControl3.Name = "tabControl3";
            tabControl3.SelectedIndex = 0;
            tabControl3.Size = new Size(742, 457);
            tabControl3.TabIndex = 0;
            // 
            // tabPage5
            // 
            tabPage5.Controls.Add(label33);
            tabPage5.Controls.Add(label29);
            tabPage5.Controls.Add(label28);
            tabPage5.Controls.Add(label30);
            tabPage5.Controls.Add(label31);
            tabPage5.Controls.Add(label32);
            tabPage5.Controls.Add(label34);
            tabPage5.Controls.Add(label35);
            tabPage5.Controls.Add(listView4);
            tabPage5.Controls.Add(label36);
            tabPage5.Location = new Point(4, 29);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(734, 424);
            tabPage5.TabIndex = 0;
            tabPage5.Text = "Countdown";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            tabPage6.Controls.Add(label37);
            tabPage6.Controls.Add(label38);
            tabPage6.Controls.Add(label39);
            tabPage6.Controls.Add(label40);
            tabPage6.Controls.Add(label41);
            tabPage6.Controls.Add(label42);
            tabPage6.Controls.Add(label43);
            tabPage6.Controls.Add(label44);
            tabPage6.Controls.Add(listView5);
            tabPage6.Controls.Add(label45);
            tabPage6.Location = new Point(4, 29);
            tabPage6.Name = "tabPage6";
            tabPage6.Padding = new Padding(3);
            tabPage6.Size = new Size(734, 424);
            tabPage6.TabIndex = 1;
            tabPage6.Text = "Timer";
            tabPage6.UseVisualStyleBackColor = true;
            // 
            // tabPage8
            // 
            tabPage8.Controls.Add(label46);
            tabPage8.Controls.Add(label47);
            tabPage8.Controls.Add(label48);
            tabPage8.Controls.Add(label49);
            tabPage8.Controls.Add(label50);
            tabPage8.Controls.Add(label51);
            tabPage8.Controls.Add(label52);
            tabPage8.Controls.Add(label53);
            tabPage8.Controls.Add(listView6);
            tabPage8.Controls.Add(label54);
            tabPage8.Location = new Point(4, 29);
            tabPage8.Name = "tabPage8";
            tabPage8.Padding = new Padding(3);
            tabPage8.Size = new Size(734, 424);
            tabPage8.TabIndex = 2;
            tabPage8.Text = "Count move";
            tabPage8.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(593, 207);
            label7.Name = "label7";
            label7.Size = new Size(17, 20);
            label7.TabIndex = 31;
            label7.Text = "0";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(593, 113);
            label6.Name = "label6";
            label6.Size = new Size(17, 20);
            label6.TabIndex = 30;
            label6.Text = "0";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(593, 161);
            label4.Name = "label4";
            label4.Size = new Size(17, 20);
            label4.TabIndex = 29;
            label4.Text = "0";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(593, 70);
            label9.Name = "label9";
            label9.Size = new Size(17, 20);
            label9.TabIndex = 28;
            label9.Text = "0";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(469, 207);
            label8.Name = "label8";
            label8.Size = new Size(103, 20);
            label8.TabIndex = 27;
            label8.Text = "Highest streak";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(469, 113);
            label5.Name = "label5";
            label5.Size = new Size(79, 20);
            label5.TabIndex = 26;
            label5.Text = "# of losses";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(469, 161);
            label3.Name = "label3";
            label3.Size = new Size(103, 20);
            label3.TabIndex = 25;
            label3.Text = "Win/lose ratio";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(469, 70);
            label2.Name = "label2";
            label2.Size = new Size(69, 20);
            label2.TabIndex = 24;
            label2.Text = "# of wins";
            // 
            // listView1
            // 
            listView1.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2 });
            listView1.Items.AddRange(new ListViewItem[] { listViewItem1, listViewItem2, listViewItem3, listViewItem4, listViewItem5, listViewItem6, listViewItem7, listViewItem8, listViewItem9, listViewItem10 });
            listView1.Location = new Point(125, 70);
            listView1.Name = "listView1";
            listView1.Size = new Size(247, 285);
            listView1.TabIndex = 23;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Rankings";
            columnHeader1.Width = 120;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Level";
            columnHeader2.Width = 120;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(201, 36);
            label10.Name = "label10";
            label10.Size = new Size(94, 20);
            label10.TabIndex = 15;
            label10.Text = "Leaderboard";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(202, 36);
            label1.Name = "label1";
            label1.Size = new Size(94, 20);
            label1.TabIndex = 14;
            label1.Text = "Leaderboard";
            label1.Click += label1_Click_1;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(593, 207);
            label12.Name = "label12";
            label12.Size = new Size(17, 20);
            label12.TabIndex = 40;
            label12.Text = "0";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(593, 113);
            label13.Name = "label13";
            label13.Size = new Size(17, 20);
            label13.TabIndex = 39;
            label13.Text = "0";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(593, 161);
            label14.Name = "label14";
            label14.Size = new Size(17, 20);
            label14.TabIndex = 38;
            label14.Text = "0";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(593, 70);
            label15.Name = "label15";
            label15.Size = new Size(17, 20);
            label15.TabIndex = 37;
            label15.Text = "0";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(469, 207);
            label16.Name = "label16";
            label16.Size = new Size(103, 20);
            label16.TabIndex = 36;
            label16.Text = "Highest streak";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(469, 113);
            label17.Name = "label17";
            label17.Size = new Size(79, 20);
            label17.TabIndex = 35;
            label17.Text = "# of losses";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(469, 161);
            label18.Name = "label18";
            label18.Size = new Size(103, 20);
            label18.TabIndex = 34;
            label18.Text = "Win/lose ratio";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(469, 70);
            label19.Name = "label19";
            label19.Size = new Size(69, 20);
            label19.TabIndex = 33;
            label19.Text = "# of wins";
            // 
            // listView2
            // 
            listView2.Columns.AddRange(new ColumnHeader[] { columnHeader3, columnHeader4 });
            listView2.Items.AddRange(new ListViewItem[] { listViewItem11, listViewItem12, listViewItem13, listViewItem14, listViewItem15, listViewItem16, listViewItem17, listViewItem18, listViewItem19, listViewItem20 });
            listView2.Location = new Point(125, 70);
            listView2.Name = "listView2";
            listView2.Size = new Size(247, 285);
            listView2.TabIndex = 32;
            listView2.UseCompatibleStateImageBehavior = false;
            listView2.View = View.Details;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Rankings";
            columnHeader3.Width = 120;
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "Level";
            columnHeader4.Width = 120;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(593, 207);
            label20.Name = "label20";
            label20.Size = new Size(17, 20);
            label20.TabIndex = 40;
            label20.Text = "0";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(593, 113);
            label21.Name = "label21";
            label21.Size = new Size(17, 20);
            label21.TabIndex = 39;
            label21.Text = "0";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(593, 161);
            label22.Name = "label22";
            label22.Size = new Size(17, 20);
            label22.TabIndex = 38;
            label22.Text = "0";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(593, 70);
            label23.Name = "label23";
            label23.Size = new Size(17, 20);
            label23.TabIndex = 37;
            label23.Text = "0";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(469, 207);
            label24.Name = "label24";
            label24.Size = new Size(103, 20);
            label24.TabIndex = 36;
            label24.Text = "Highest streak";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(469, 113);
            label25.Name = "label25";
            label25.Size = new Size(79, 20);
            label25.TabIndex = 35;
            label25.Text = "# of losses";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(469, 161);
            label26.Name = "label26";
            label26.Size = new Size(103, 20);
            label26.TabIndex = 34;
            label26.Text = "Win/lose ratio";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(469, 70);
            label27.Name = "label27";
            label27.Size = new Size(69, 20);
            label27.TabIndex = 33;
            label27.Text = "# of wins";
            // 
            // listView3
            // 
            listView3.Columns.AddRange(new ColumnHeader[] { columnHeader5, columnHeader6 });
            listView3.Items.AddRange(new ListViewItem[] { listViewItem21, listViewItem22, listViewItem23, listViewItem24, listViewItem25, listViewItem26, listViewItem27, listViewItem28, listViewItem29, listViewItem30 });
            listView3.Location = new Point(125, 70);
            listView3.Name = "listView3";
            listView3.Size = new Size(247, 285);
            listView3.TabIndex = 32;
            listView3.UseCompatibleStateImageBehavior = false;
            listView3.View = View.Details;
            // 
            // columnHeader5
            // 
            columnHeader5.Text = "Rankings";
            columnHeader5.Width = 120;
            // 
            // columnHeader6
            // 
            columnHeader6.Text = "Level";
            columnHeader6.Width = 120;
            // 
            // label37
            // 
            label37.AutoSize = true;
            label37.Location = new Point(588, 175);
            label37.Name = "label37";
            label37.Size = new Size(41, 20);
            label37.TabIndex = 53;
            label37.Text = "from";
            // 
            // label38
            // 
            label38.AutoSize = true;
            label38.Location = new Point(588, 139);
            label38.Name = "label38";
            label38.Size = new Size(41, 20);
            label38.TabIndex = 52;
            label38.Text = "from";
            // 
            // label39
            // 
            label39.AutoSize = true;
            label39.Location = new Point(516, 175);
            label39.Name = "label39";
            label39.Size = new Size(17, 20);
            label39.TabIndex = 51;
            label39.Text = "0";
            // 
            // label40
            // 
            label40.AutoSize = true;
            label40.Location = new Point(553, 139);
            label40.Name = "label40";
            label40.Size = new Size(17, 20);
            label40.TabIndex = 50;
            label40.Text = "0";
            // 
            // label41
            // 
            label41.AutoSize = true;
            label41.Location = new Point(516, 87);
            label41.Name = "label41";
            label41.Size = new Size(17, 20);
            label41.TabIndex = 49;
            label41.Text = "0";
            // 
            // label42
            // 
            label42.AutoSize = true;
            label42.Location = new Point(392, 175);
            label42.Name = "label42";
            label42.Size = new Size(103, 20);
            label42.TabIndex = 48;
            label42.Text = "Highest streak";
            // 
            // label43
            // 
            label43.AutoSize = true;
            label43.Location = new Point(392, 139);
            label43.Name = "label43";
            label43.Size = new Size(155, 20);
            label43.TabIndex = 47;
            label43.Text = "Highest win/lose ratio";
            // 
            // label44
            // 
            label44.AutoSize = true;
            label44.Location = new Point(392, 87);
            label44.Name = "label44";
            label44.Size = new Size(85, 20);
            label44.TabIndex = 46;
            label44.Text = "# of battles";
            // 
            // listView5
            // 
            listView5.Columns.AddRange(new ColumnHeader[] { columnHeader9, columnHeader10 });
            listView5.Items.AddRange(new ListViewItem[] { listViewItem41, listViewItem42, listViewItem43, listViewItem44, listViewItem45, listViewItem46, listViewItem47, listViewItem48, listViewItem49, listViewItem50 });
            listView5.Location = new Point(106, 87);
            listView5.Name = "listView5";
            listView5.Size = new Size(247, 285);
            listView5.TabIndex = 45;
            listView5.UseCompatibleStateImageBehavior = false;
            listView5.View = View.Details;
            // 
            // columnHeader9
            // 
            columnHeader9.Text = "Rankings";
            columnHeader9.Width = 120;
            // 
            // columnHeader10
            // 
            columnHeader10.Text = "# of wins";
            columnHeader10.Width = 120;
            // 
            // label45
            // 
            label45.AutoSize = true;
            label45.Location = new Point(183, 53);
            label45.Name = "label45";
            label45.Size = new Size(94, 20);
            label45.TabIndex = 44;
            label45.Text = "Leaderboard";
            // 
            // label46
            // 
            label46.AutoSize = true;
            label46.Location = new Point(588, 175);
            label46.Name = "label46";
            label46.Size = new Size(41, 20);
            label46.TabIndex = 53;
            label46.Text = "from";
            // 
            // label47
            // 
            label47.AutoSize = true;
            label47.Location = new Point(588, 139);
            label47.Name = "label47";
            label47.Size = new Size(41, 20);
            label47.TabIndex = 52;
            label47.Text = "from";
            // 
            // label48
            // 
            label48.AutoSize = true;
            label48.Location = new Point(516, 175);
            label48.Name = "label48";
            label48.Size = new Size(17, 20);
            label48.TabIndex = 51;
            label48.Text = "0";
            // 
            // label49
            // 
            label49.AutoSize = true;
            label49.Location = new Point(553, 139);
            label49.Name = "label49";
            label49.Size = new Size(17, 20);
            label49.TabIndex = 50;
            label49.Text = "0";
            // 
            // label50
            // 
            label50.AutoSize = true;
            label50.Location = new Point(516, 87);
            label50.Name = "label50";
            label50.Size = new Size(17, 20);
            label50.TabIndex = 49;
            label50.Text = "0";
            // 
            // label51
            // 
            label51.AutoSize = true;
            label51.Location = new Point(392, 175);
            label51.Name = "label51";
            label51.Size = new Size(103, 20);
            label51.TabIndex = 48;
            label51.Text = "Highest streak";
            // 
            // label52
            // 
            label52.AutoSize = true;
            label52.Location = new Point(392, 139);
            label52.Name = "label52";
            label52.Size = new Size(155, 20);
            label52.TabIndex = 47;
            label52.Text = "Highest win/lose ratio";
            // 
            // label53
            // 
            label53.AutoSize = true;
            label53.Location = new Point(392, 87);
            label53.Name = "label53";
            label53.Size = new Size(85, 20);
            label53.TabIndex = 46;
            label53.Text = "# of battles";
            // 
            // listView6
            // 
            listView6.Columns.AddRange(new ColumnHeader[] { columnHeader11, columnHeader12 });
            listView6.Items.AddRange(new ListViewItem[] { listViewItem51, listViewItem52, listViewItem53, listViewItem54, listViewItem55, listViewItem56, listViewItem57, listViewItem58, listViewItem59, listViewItem60 });
            listView6.Location = new Point(106, 87);
            listView6.Name = "listView6";
            listView6.Size = new Size(247, 285);
            listView6.TabIndex = 45;
            listView6.UseCompatibleStateImageBehavior = false;
            listView6.View = View.Details;
            // 
            // columnHeader11
            // 
            columnHeader11.Text = "Rankings";
            columnHeader11.Width = 120;
            // 
            // columnHeader12
            // 
            columnHeader12.Text = "# of wins";
            columnHeader12.Width = 120;
            // 
            // label54
            // 
            label54.AutoSize = true;
            label54.Location = new Point(183, 53);
            label54.Name = "label54";
            label54.Size = new Size(94, 20);
            label54.TabIndex = 44;
            label54.Text = "Leaderboard";
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Location = new Point(588, 175);
            label33.Name = "label33";
            label33.Size = new Size(41, 20);
            label33.TabIndex = 53;
            label33.Text = "from";
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(588, 139);
            label29.Name = "label29";
            label29.Size = new Size(41, 20);
            label29.TabIndex = 52;
            label29.Text = "from";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Location = new Point(516, 175);
            label28.Name = "label28";
            label28.Size = new Size(17, 20);
            label28.TabIndex = 51;
            label28.Text = "0";
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Location = new Point(553, 139);
            label30.Name = "label30";
            label30.Size = new Size(17, 20);
            label30.TabIndex = 50;
            label30.Text = "0";
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Location = new Point(516, 87);
            label31.Name = "label31";
            label31.Size = new Size(17, 20);
            label31.TabIndex = 49;
            label31.Text = "0";
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Location = new Point(392, 175);
            label32.Name = "label32";
            label32.Size = new Size(103, 20);
            label32.TabIndex = 48;
            label32.Text = "Highest streak";
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Location = new Point(392, 139);
            label34.Name = "label34";
            label34.Size = new Size(155, 20);
            label34.TabIndex = 47;
            label34.Text = "Highest win/lose ratio";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Location = new Point(392, 87);
            label35.Name = "label35";
            label35.Size = new Size(85, 20);
            label35.TabIndex = 46;
            label35.Text = "# of battles";
            // 
            // listView4
            // 
            listView4.Columns.AddRange(new ColumnHeader[] { columnHeader7, columnHeader8 });
            listView4.Items.AddRange(new ListViewItem[] { listViewItem31, listViewItem32, listViewItem33, listViewItem34, listViewItem35, listViewItem36, listViewItem37, listViewItem38, listViewItem39, listViewItem40 });
            listView4.Location = new Point(106, 87);
            listView4.Name = "listView4";
            listView4.Size = new Size(247, 285);
            listView4.TabIndex = 45;
            listView4.UseCompatibleStateImageBehavior = false;
            listView4.View = View.Details;
            // 
            // columnHeader7
            // 
            columnHeader7.Text = "Rankings";
            columnHeader7.Width = 120;
            // 
            // columnHeader8
            // 
            columnHeader8.Text = "# of wins";
            columnHeader8.Width = 120;
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Location = new Point(183, 53);
            label36.Name = "label36";
            label36.Size = new Size(94, 20);
            label36.TabIndex = 44;
            label36.Text = "Leaderboard";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            ClientSize = new Size(756, 496);
            Controls.Add(tabControl1);
            Name = "Form1";
            Text = "Score";
            Load += Form1_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabControl2.ResumeLayout(false);
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            tabPage4.ResumeLayout(false);
            tabPage4.PerformLayout();
            tabPage7.ResumeLayout(false);
            tabPage7.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabControl3.ResumeLayout(false);
            tabPage5.ResumeLayout(false);
            tabPage5.PerformLayout();
            tabPage6.ResumeLayout(false);
            tabPage6.PerformLayout();
            tabPage8.ResumeLayout(false);
            tabPage8.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabControl tabControl2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private TabPage tabPage7;
        private Label label11;
        private TabPage tabPage2;
        private TabControl tabControl3;
        private TabPage tabPage5;
        private TabPage tabPage6;
        private TabPage tabPage8;
        private Label label7;
        private Label label6;
        private Label label4;
        private Label label9;
        private Label label8;
        private Label label5;
        private Label label3;
        private Label label2;
        private ListView listView1;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private Label label1;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private ListView listView2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private Label label10;
        private Label label20;
        private Label label21;
        private Label label22;
        private Label label23;
        private Label label24;
        private Label label25;
        private Label label26;
        private Label label27;
        private ListView listView3;
        private ColumnHeader columnHeader5;
        private ColumnHeader columnHeader6;
        private Label label33;
        private Label label29;
        private Label label28;
        private Label label30;
        private Label label31;
        private Label label32;
        private Label label34;
        private Label label35;
        private ListView listView4;
        private ColumnHeader columnHeader7;
        private ColumnHeader columnHeader8;
        private Label label36;
        private Label label37;
        private Label label38;
        private Label label39;
        private Label label40;
        private Label label41;
        private Label label42;
        private Label label43;
        private Label label44;
        private ListView listView5;
        private ColumnHeader columnHeader9;
        private ColumnHeader columnHeader10;
        private Label label45;
        private Label label46;
        private Label label47;
        private Label label48;
        private Label label49;
        private Label label50;
        private Label label51;
        private Label label52;
        private Label label53;
        private ListView listView6;
        private ColumnHeader columnHeader11;
        private ColumnHeader columnHeader12;
        private Label label54;
    }
}
