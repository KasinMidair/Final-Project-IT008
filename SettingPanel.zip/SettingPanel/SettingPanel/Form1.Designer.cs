﻿namespace SettingPanel
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            trackBar1 = new TrackBar();
            label1 = new Label();
            button2 = new Button();
            button1 = new Button();
            button3 = new Button();
            button4 = new Button();
            label2 = new Label();
            trackBar2 = new TrackBar();
            button5 = new Button();
            button6 = new Button();
            label3 = new Label();
            trackBar3 = new TrackBar();
            groupBox1 = new GroupBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            groupBox2 = new GroupBox();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            label7 = new Label();
            comboBox1 = new ComboBox();
            radioButton3 = new RadioButton();
            radioButton4 = new RadioButton();
            groupBox3 = new GroupBox();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            ((System.ComponentModel.ISupportInitialize)trackBar1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar3).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // trackBar1
            // 
            trackBar1.Location = new Point(179, 31);
            trackBar1.Name = "trackBar1";
            trackBar1.Size = new Size(130, 56);
            trackBar1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 31);
            label1.Name = "label1";
            label1.Size = new Size(108, 20);
            label1.TabIndex = 1;
            label1.Text = "Master Volume";
            label1.Click += label1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(143, 31);
            button2.Name = "button2";
            button2.Size = new Size(30, 30);
            button2.TabIndex = 3;
            button2.Text = "<";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(315, 31);
            button1.Name = "button1";
            button1.Size = new Size(30, 30);
            button1.TabIndex = 4;
            button1.Text = ">";
            button1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(315, 84);
            button3.Name = "button3";
            button3.Size = new Size(30, 30);
            button3.TabIndex = 8;
            button3.Text = ">";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(143, 84);
            button4.Name = "button4";
            button4.Size = new Size(30, 30);
            button4.TabIndex = 7;
            button4.Text = "<";
            button4.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(24, 84);
            label2.Name = "label2";
            label2.Size = new Size(47, 20);
            label2.TabIndex = 6;
            label2.Text = "Music";
            // 
            // trackBar2
            // 
            trackBar2.Location = new Point(179, 84);
            trackBar2.Name = "trackBar2";
            trackBar2.Size = new Size(130, 56);
            trackBar2.TabIndex = 5;
            // 
            // button5
            // 
            button5.Location = new Point(315, 146);
            button5.Name = "button5";
            button5.Size = new Size(30, 30);
            button5.TabIndex = 12;
            button5.Text = ">";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(143, 146);
            button6.Name = "button6";
            button6.Size = new Size(30, 30);
            button6.TabIndex = 11;
            button6.Text = "<";
            button6.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(24, 146);
            label3.Name = "label3";
            label3.Size = new Size(99, 20);
            label3.TabIndex = 10;
            label3.Text = "Sound Effects";
            // 
            // trackBar3
            // 
            trackBar3.Location = new Point(179, 146);
            trackBar3.Name = "trackBar3";
            trackBar3.Size = new Size(130, 56);
            trackBar3.TabIndex = 9;
            // 
            // groupBox1
            // 
            groupBox1.Anchor = AnchorStyles.None;
            groupBox1.AutoSize = true;
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(trackBar1);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(button5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(button6);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(trackBar3);
            groupBox1.Controls.Add(trackBar2);
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(button4);
            groupBox1.Location = new Point(161, 45);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(566, 228);
            groupBox1.TabIndex = 13;
            groupBox1.TabStop = false;
            groupBox1.Text = "Audio";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(376, 146);
            label6.Name = "label6";
            label6.Size = new Size(136, 20);
            label6.TabIndex = 16;
            label6.Text = "SoundEffects_value";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(376, 89);
            label5.Name = "label5";
            label5.Size = new Size(88, 20);
            label5.TabIndex = 15;
            label5.Text = "Music_value";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(376, 36);
            label4.Name = "label4";
            label4.Size = new Size(145, 20);
            label4.TabIndex = 14;
            label4.Text = "MasterVolume_value";
            label4.Click += label4_Click;
            // 
            // groupBox2
            // 
            groupBox2.Anchor = AnchorStyles.None;
            groupBox2.AutoSize = true;
            groupBox2.Controls.Add(radioButton2);
            groupBox2.Controls.Add(radioButton1);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(comboBox1);
            groupBox2.Location = new Point(161, 264);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(566, 121);
            groupBox2.TabIndex = 14;
            groupBox2.TabStop = false;
            groupBox2.Text = "Graphic";
            groupBox2.Enter += groupBox2_Enter;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(207, 26);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(102, 24);
            radioButton2.TabIndex = 5;
            radioButton2.Text = "Windowed";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Checked = true;
            radioButton1.Location = new Point(24, 26);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(95, 24);
            radioButton1.TabIndex = 4;
            radioButton1.TabStop = true;
            radioButton1.Text = "Fullscreen";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(23, 70);
            label7.Name = "label7";
            label7.Size = new Size(79, 20);
            label7.TabIndex = 1;
            label7.Text = "Resolution";
            // 
            // comboBox1
            // 
            comboBox1.AccessibleDescription = "";
            comboBox1.DisplayMember = "1";
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Fullscreen", "Windowed" });
            comboBox1.Location = new Point(169, 67);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 28);
            comboBox1.TabIndex = 0;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(212, 26);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(97, 24);
            radioButton3.TabIndex = 15;
            radioButton3.TabStop = true;
            radioButton3.Text = "Tiếng Việt";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Checked = true;
            radioButton4.Location = new Point(25, 26);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(77, 24);
            radioButton4.TabIndex = 16;
            radioButton4.TabStop = true;
            radioButton4.Text = "English";
            radioButton4.UseVisualStyleBackColor = true;
            radioButton4.CheckedChanged += radioButton4_CheckedChanged;
            // 
            // groupBox3
            // 
            groupBox3.Anchor = AnchorStyles.None;
            groupBox3.AutoSize = true;
            groupBox3.Controls.Add(radioButton4);
            groupBox3.Controls.Add(radioButton3);
            groupBox3.Location = new Point(161, 384);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(566, 76);
            groupBox3.TabIndex = 17;
            groupBox3.TabStop = false;
            groupBox3.Text = "Language";
            // 
            // button7
            // 
            button7.Anchor = AnchorStyles.None;
            button7.AutoSize = true;
            button7.Location = new Point(12, 12);
            button7.Name = "button7";
            button7.Size = new Size(132, 30);
            button7.TabIndex = 18;
            button7.Text = "Return to menu";
            button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.Anchor = AnchorStyles.None;
            button8.AutoSize = true;
            button8.Location = new Point(356, 466);
            button8.Name = "button8";
            button8.Size = new Size(164, 30);
            button8.TabIndex = 19;
            button8.Text = "Reset Settings";
            button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Anchor = AnchorStyles.None;
            button9.AutoSize = true;
            button9.Location = new Point(356, 501);
            button9.Name = "button9";
            button9.Size = new Size(164, 34);
            button9.TabIndex = 20;
            button9.Text = "Reset Save Data";
            button9.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            ClientSize = new Size(941, 564);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Settings";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)trackBar1).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar2).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar3).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TrackBar trackBar1;
        private Label label1;
        private Button button2;
        private Button button1;
        private Button button3;
        private Button button4;
        private Label label2;
        private TrackBar trackBar2;
        private Button button5;
        private Button button6;
        private Label label3;
        private TrackBar trackBar3;
        private GroupBox groupBox1;
        private Label label4;
        private Label label5;
        private Label label6;
        private GroupBox groupBox2;
        private ComboBox comboBox1;
        private Label label7;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private RadioButton radioButton3;
        private RadioButton radioButton4;
        private GroupBox groupBox3;
        private Button button7;
        private Button button8;
        private Button button9;
    }
}
